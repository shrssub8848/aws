
**To leave an organization as a member account**

The following example shows the administrator of a member account requesting to leave the organization it is currently a member of: ::

	aws organizations leave-organization